<html> 
<body> 
<form action="perfect.jsp" method="post"> 
Enter any no:<input type="text" name="t1" > 
<br> 
<input type="submit" > 
</form> 
</body> 
</html> 
Perfect. jsp 
<%@ page language="java" %> 
<html> 
<body> 
<% 
int n=Integer.parseInt(request.getParameter("t1")); 
out.println(" given number is: "+n); 
int sum = 0; 
for(int i = 1; i < n; i++) 
{ 
if(n % i == 0) 
{ 
sum = sum + i; 
} 
} 
if(sum == n) 
{ 
out.println("<br>"+n+" is Perfect no."); 
} 
else 
{ 
out.println("<br>"+n+" is not Perfect"); 
}   
%>       
</body> </html>  