firstlast.html 
<html> 
<body> 
<form action="firstlast.jsp" method="get"> 
Enter No: <input type="text" name="fno" /> 
<br> 
<input type="submit" /> 
</form> 
</body> 
<html> 
firstlast.jsp 
<%@ page language="java" %> 
<html> 
<body> 
<%!int i,n,sum=0;%> 
<%int n=Integer.parseInt(request.getParameter("fno")); %> 
<% 
if(n>10)   
{  
sum += n % 10;   
}  
while(n>10)  
{  
n = n / 10;  
}  
sum += n;   
out.println("\nSum of first and last digit = "+ sum);  
%> 
<font size=18 color='red'> 
Sum = <%=sum%> 
</font> 
<br> 
</body> 
</html> 