//Server side 
import java.io.*; 
import java.net.*; 
  
public class Slip3AB{ 
    public static void main(String args[]) throws Exception { 
        ServerSocket ss = new ServerSocket(7500); 
        Socket s = ss.accept(); 
  
        DataInputStream dis = new DataInputStream(s.getInputStream()); 
        int n1 = Integer.parseInt(dis.readLine()); 
  
        int i, cnt = 0; 
  
        for (i = 2; i < n1; i++) { 
            if (n1 % i == 0) 
                cnt++; 
            break; 
        } 
  
        DataOutputStream dos = new DataOutputStream(s.getOutputStream()); 
  
        if (cnt == 0) 
            dos.writeBytes(n + " is prime number."); 
        else 
            dos.writeBytes(n + " is not prime number."); 
  
        s.close(); 
  
    } 
} 
   
 
 
 
//Client Side 
import java.io.*; 
import java.net.*; 
public class Slip3Aa { 
    public static void main(String args[]) throws Exception { 
        Socket s = new Socket("localhost", 7500); 
        DataInputStream din = new DataInputStream(System.in); 
        System.out.print("Enter any number:"); 
         String n = din.readLine(); 
         DataOutputStream dos = new DataOutputStream(s.getOutputStream())
 ; 
        dos.writeBytes(n1 + "\n"); 
         DataInputStream dis = new DataInputStream(s.getInputStream()); 
        System.out.println(dis.readLine()); 
  
    } 
} 
 
