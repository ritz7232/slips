number.jsp 
 
<font color='blue'> 
<% 
            String words[]={"Zero","One","Two","Three","Four","Five", 
                                    "Six","Seven","Eight","Nine"}; 
 
            String s = request.getParameter("no"); 
 
            for(int i=0;i<s.length();i++){ 
                        out.print(words[s.charAt(i)-'0']+" "); 
            } 
%> 
</font>            
 
number.html 
<form method='post' action='number.jsp'> 
Number:<input type='text' name='no'><br> 
<input type='submit'><input type='reset'>
</form>