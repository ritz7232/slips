/*<APPLET code = "slip1a.class" width = 500 height = 500 >
</APPLET>*/
// Java Code to implement Moving text using
// applet and thread.
importjava.awt.*;
importjava.applet.*;
public class slip1a extends Applet implements Runnable {
	private String display;
	privateint x, y, flag;
	Thread t;
	// initializing
	// called when the applet is
	// started.
	public void init()
	{
		display = "Hello Java...";
		x = 100;
		y = 100;
		flag = 1;
		// creating thread
		t = new Thread(this, "MyThread");
		// start thread
		t.start();
	}
	// update the x co-ordinate
	public void update()
	{
		x = x + 10 * flag;
		if (x > 300)
			flag = -1;
		if (x < 100)
			flag = 1;
	}
	// run
	public void run()
	{
		while (true) {
			// Repainting the screen
			// calls the paint function
			repaint();
			update();
			try {
				// creating a pause of 1 second
				// so that the movement is recognizable
				Thread.sleep(1000);
			}
			catch (InterruptedExceptionie) {
				System.out.println(ie);
			}
		}
	}
	// drawString
	public void paint(Graphics g)
	{
		g.drawString(display, x, y);
	}
}
