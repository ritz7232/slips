Page1.html 
      
<form method='post' action='page1.jsp'> 
<h3>Page 1</h3> 
<h4>Select Your Product:</h4> 
<input type='checkbox' name='prod' value=10>Pencil<br> 
<input type='checkbox' name='prod' value=30>Pen<br> 
<input type='checkbox' name='prod' value=5>Eraser<br> 
<input type='checkbox' name='prod' value=8>Scale<br> 
(UseSession)(slip9(2)) 
<input type='checkbox' name='prod' value=45>Note Book<br> 
<input type='submit'><input type='reset'> 
</form>                                                                                                                           
page1.jsp 
<% 
String s[] = request.getParameterValues("prod"); 
int tot=0; 
for(int i=0;i<s.length;i++){ 
tot+=Integer.parseInt(s[i]); 
} 
session.setAttribute("tot1", tot); 
response.sendRedirect("Page2.html"); 
%> 
Page2.html 
<form method='post' action='page2.jsp'> 
<h3>Page 2</h3> 
<h4>Select Your Product:</h4> 
<input type='checkbox' name='prod' value=1300>Jeans<br> 
<input type='checkbox' name='prod' value=500>Shirt<br> 
<input type='checkbox' name='prod' value=2500>Saree<br> 
<input type='checkbox' name='prod' value=750>Trouser<br> 
<input type='checkbox' name='prod' value=400>T-Shirt<br> 
<input type='submit'><input type='reset'> 
</form> 
page2.jsp 
<% 
String s[] = request.getParameterValues("prod"); 
int tot=0; 
for(int i=0;i<s.length;i++){ 
tot+=Integer.parseInt(s[i]); 
} 
int tot1 = Integer.parseInt(session.getAttribute("tot1").toString()); 
%> 
<table border=1> 
<tr><td><b>Page 1:</b></td><td>Rs.<%=tot1%>/-</td></tr> 
<tr><td><b>Page 2:</b></td><td>Rs.<%=tot%>/-</td></tr> 
<tr><td><b>Grand Total:</b></td><td>Rs.<%=tot1+tot%>/-</td></tr> 
</table>