import java.io.*;
public class Slip17 {
 public static void main(String args[]) {
 alphabets b1 = new alphabets();
 b1.start();
     }
 }
 class alphabets extends Thread {
   public void run()
{
         try
{
             DataInputStream din = new DataInputStream(System.in);
             System.out.print("Enter String : ");
             String str = din.readLine();
             String str1 = str.toLowerCase();
             for(int i=0; i<=str1.length(); i++){
                 if(str1.charAt(i)=='a' || str1.charAt(i)=='e'|| str1.charAt(i)=='i' || str1.charAt(i)=='o' || str1.charAt(i)=='u' )
{
                     System.out.println(str1.charAt(i));
                     sleep(3000);
                 }
 }
                }
catch(Exception e)
{
}
 }
 }
