import java.io.*;
import java.util.*;
import java.applet.Applet;
import java.awt.*;
/*<applet code="Tsgnl.class" height=300 width=300>*/
public class Tsgnl extends Applet implements Runnable
{
Thread t;
int x=0;
public void run()
{
repaint();
}
public void init()
{
Tsgnlts=new Tsgnl();
t=new Thread(ts);
t.start();
setSize(500,500);
setBackground(Color.pink);
}
public void paint(Graphics g)
{
g.setColor(Color.blue);
g.fillRect(200,100,100,270);
g.setColor(Color.white);
g.drawOval(220,120,70,70);
g.drawOval(220,200,70,70);
g.drawOval(220,280,70,70);
if(x==0)
{
g.setColor(Color.red);
g.fillOval(220,120,70,70);
x=1;
}
else if(x==1)
{
g.setColor(Color.yellow);
g.fillOval(220,200,70,70);
x=2;
}
else
{
g.setColor(Color.green);
g.fillOval(220,280,70,70);
x=0;
}
try
{
Thread.sleep(3000);
}
catch(Exception e)
{
e.printStackTrace();
}
repaint();
}
public static void main(String args[])
{
newTsgnl();
}
}
