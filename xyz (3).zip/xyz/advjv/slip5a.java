firstlast.html 
<html> 
<body> 
<form action="firstlast.jsp" method="get"> 
Enter No: <input type="text" name="fno" /> 
<br> 
<input type="submit" /> 
</form> 
</body> 
<html> 
firstlast.jsp 
<%@ page language="java" %> 
<html> 
<body> 
<% 
int n = Integer.parseInt(request.getParameter("fno")); 
int sum = 0; // Declare sum as a local variable

if(n > 10) {  
    sum += n % 10;   
}  
while(n > 10) {  
    n = n / 10;  
}  
sum += n;   
out.println("\nSum of first and last digit = " + sum);  
%> 
<font size=18 color='red'> 
Sum = <%=sum%> 
</font> 
<br> 
</body> 
</html>