import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
class slipemp implements ItemListener
{
JFrame f;
JComboBox cb;
JPanel p;
JLabel l,l1,l2,l3;
Connection conn = null;
Statement stmt = null;
PreparedStatement ps = null;
ResultSet rs,rs1 = null;
Slip28_2()
{
f = new JFrame("Employee Information");
p = new JPanel();
l = new JLabel("Select emp No : ");
l1 = new JLabel();
l2 = new JLabel();
l3 = new JLabel();
try
{
Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
conn = DriverManager.getConnection("jdbc:odbc:dsn11");
stmt = conn.createStatement();
Vector v = new Vector();
rs = stmt.executeQuery("select eno from employee");
while(rs.next())
{
v.add(rs.getInt(1));
}
cb = new JComboBox(v);
cb.addItemListener(this);
}
catch(Exception e)
{
e.printStackTrace();
}
p.add(l);
p.add(cb);
p.add(l1);
p.add(l2);
p.add(l3);
f.add(p);
f.setSize(400, 400);
f.setVisible(true);
}
public void itemStateChanged(ItemEvent e)
{
JComboBox source = (JComboBox)e.getSource();
Integer emp_no = (Integer)source.getSelectedItem();
try
{
rs1 = stmt.executeQuery("select * from employee where eno ="+emp_no);
if(rs1.next())
{
l1.setText("\nEmp No : "+rs1.getInt(1));
l2.setText("\nName : "+rs1.getString(2));
l3.setText("\nSalary : "+rs1.getInt(3));
}

}
catch(Exception ex)
{
System.out.println(ex);
}
}
public static void main(String args[])
{
slipemp obj = new slipemp();
}