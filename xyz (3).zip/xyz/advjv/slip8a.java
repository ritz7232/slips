import java.sql.*;  //step 1 - import the package

public class selectEmployee
{
	public static void main(String args[]) throws Exception
	{
	Connection con;
	Statement st;
	String query;
	ResultSet rs;
	
	Class.forName("com.mysql.jdbc.Driver");  
	
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb","root",""); 	
	st=con.createStatement();  
	
	query="select * from emp where ename like 'A%'"; 
	
	rs=st.executeQuery(query); 
	while(rs.next())
	{
	System.out.println(rs.getInt("eid") + rs.getString("ename") + rs.getInt("esal"));
	}
	
	st.close();		
	con.close();
	}
}