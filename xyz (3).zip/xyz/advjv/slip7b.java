importjava.awt.*;
importjava.awt.event.*;

public class thread7 extends Frame implements ActionListener,Runnable
{
    Button b1,b2;
   TextField t11,t12;
    intcnt;
   Thread t1 = new Thread(this,"t1");
    Thread t2=new Thread(this,"t2");
            public thread7()
   {
         setLayout(null);
         t11=new TextField();
         t12=new TextField();
         b1=new Button("Start");
         b2=new Button("Stop");
          t11.setBounds(50,50,100,100);
          t12.setBounds(160,50,100,100);
         b1.setBounds(50,170,100,30);
          b2.setBounds(160,170,100,30);
           add(t11);
        add(t12);
        b1.addActionListener(this);
         b2.addActionListener(this);
        add(b1);
        add(b2);
      
        setSize(400,400);
        setVisible(true);
         cnt=0;

                    addWindowListener(new WindowAdapter()
                {
                    public void windowClosing(WindowEvent e)
                    {
                        System.exit(0);
                    }
                });

    }
    public void actionPerformed(ActionEventae)
    {
           String str;
           str=ae.getActionCommand();
           if(str.equals("Start"))
          {
                   
      t1.start();
      t2.start();
          }
         else if(str.equals("Stop"))
      {
            t1.stop();
            t2.stop();
      }
    }
     public void run()
    {
                 try
                 {
                  for(int i=1;i<=100;i++)
                   {
                  t11.setText(" "+i);
                  t1.sleep(150);
                  t12.setText(""+i);
                  t2.sleep(150);
                  }
                }
                catch(Exception e)
                {
}
      }
    public static void main(String args[])
        {
           
 new thread7().show();     
        }
}
