Slip 11 - A) Write a java program to display IPAddress and name of client machine.
Solution:
import java.net.*;
public class IPTest
{
	public static void main(String args[])throws UnknownHostException
	{
		InetAddress addr=InetAddress.getLocalHost();
		String ipAddress=addr.getHostAddress();
		System.out.println("IP Address of localhost from Java Program:"+ ipAddress);
		String hostname=addr.getHostName();
		System.out.println("Name of hostname:"+hostname);
	}
}