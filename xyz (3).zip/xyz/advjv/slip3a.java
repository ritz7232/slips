//Server side 
import java.io.*; 
import java.net.*; 
  
public class primeserver { 
    public static void main(String args[]) throws Exception { 
        ServerSocket ss = new ServerSocket(7500); 
        System.out.println("Server is listening on port 7500");
        
        while (true) {
            Socket s = ss.accept(); 
            System.out.println("Client connected");

            DataInputStream dis = new DataInputStream(s.getInputStream()); 
            int n1 = Integer.parseInt(dis.readLine()); 

            int cnt = 0; 

            for (int i = 2; i <= Math.sqrt(n1); i++) { 
                if (n1 % i == 0) { 
                    cnt++; 
                    break; 
                } 
            } 

            DataOutputStream dos = new DataOutputStream(s.getOutputStream()); 

            if (cnt == 0 && n1 > 1) 
                dos.writeBytes(n1 + " is a prime number.\n"); 
            else 
                dos.writeBytes(n1 + " is not a prime number.\n"); 

            s.close(); 
        }
    } 
}   
 
 
 
//Client Side 
import java.io.*; 
import java.net.*; 

public class primeclient { 
    public static void main(String args[]) throws Exception { 
        Socket s = new Socket("localhost", 7500); 
        DataInputStream din = new DataInputStream(System.in); 
        System.out.print("Enter any number: "); 
        String n = din.readLine(); 
        
        DataOutputStream dos = new DataOutputStream(s.getOutputStream()); 
        dos.writeBytes(n + "\n"); 
        
        DataInputStream dis = new DataInputStream(s.getInputStream()); 
        System.out.println(dis.readLine()); 
        
        s.close(); 
    } 
} 
