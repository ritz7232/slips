login.jsp 
<%@ page language="java"%> 
<html> 
<body> 
<% String username = request.getParameter("username"); 
String password = request.getParameter("password"); 
if (username != null && password != null && username.equals(password)) { 
%> 
<h1>Login Successfully</h1> 
<% } else { %> 
<h1>Login Failed</h1> 
<% } %> 
</body> 
</html> 
login.html 
<html> 
<body> 
<form action="login.jsp" method="post"> 
<label for="username">Username:</label> 
<input type="text" id="username" name="username" required><br> 
<label for="password">Password:</label> 
<input type="password" id="password" name="password" required><br> 
<input type="submit" value="Login"> 
</form> 
</body> 
</html>