 importjava.awt.*;
 public class Bimage extends Frame 
{
     int f = 0;
 publicBimage()
 {
         Blink s = new Blink();
         s.start();
         setSize(500, 500);
         setVisible(true);
    } 
    class Blink extends Thread
 {
        public void run() 
{
            while (true) 
{
                f = (f + 1) % 2;
                repaint();
                try
 {
                    Thread.sleep(500);
                }
catch (Exception e)
 {

                }
          }
        }
    }
 
    public void paint(Graphics g) 
{
 
        Toolkit t = Toolkit.getDefaultToolkit();
 
        Image img = t.getImage("Tulips.jpg");
 
        switch (f) {
 
            case 0:
 
                g.drawImage(img, 150, 100, this);
        }
    }

    public static void main(String args[])
 {
        newBimage(); 
    } 
}





